package ObjectMaster;

public class HumanTest {
    public static void main(String[]args){
        Human h = new Human(100);
        Human h1 = new Human(100);
        h.attack(h1);

    }
}
