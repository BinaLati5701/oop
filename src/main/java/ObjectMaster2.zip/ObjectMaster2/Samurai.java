package ObjectMaster2;

public class Samurai extends Human{
    protected  int health = 200;

    public Samurai(int health) {
        super(health);
    }

    public void deathBlow(Human h){
        h.setHealth(h.getHealth() - h.getHealth());
        health = health/2;


    }
    public void meditate(){
        this.setHealth(this.getHealth() + this.getHealth()/2);

    }
    public Integer howMany(int samuraiCount){
        return samuraiCount;

    }

}

